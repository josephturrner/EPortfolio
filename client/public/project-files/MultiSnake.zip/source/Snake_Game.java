import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Random; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Snake_Game extends PApplet {

Start myStart = new Start();
Screen myScreen;
int highScore = 0;
String high = "";

public void setup() {

  
  frameRate(100);
  
}

int frame = 0;

public void draw() {
  
  if (myStart.start) {
    myStart.drawStart();
  }
  if (!myStart.start && myScreen.multiplayer) {
    if (highScore < myScreen.snake1.score) {
      highScore = myScreen.snake1.score;
      high = "Green";
    } else if (highScore < myScreen.snake2.score) {
      highScore = myScreen.snake2.score;
      high = "Blue";
    }
  } else if (!myStart.start && !myScreen.multiplayer) { 
    if (!myStart.start && highScore < myScreen.snake1.score) {
      highScore = myScreen.snake1.score;
    }
  }
  if (!myStart.start && myScreen.multiplayer) {
    if (!myStart.start && myScreen.time && (myScreen.snake1.alive || myScreen.snake2.alive)) {
      if (frame % myStart.speed == 0) {
        myScreen.updateScreen();
        textSize(myStart.size/2);
        fill(255, 255, 255);
        if (highScore == 0) {
          text("High Score:" + highScore, myScreen.size.x/2 - 65, myScreen.size.y - myStart.size/2);
        } else {
          text("High Score - " + high + ": " + highScore, myScreen.size.x/2 - 65, myScreen.size.y - myStart.size/2);
        }
      }
      frame += 1;
      myScreen.changeSnakeColor();
    }
  } else if (!myStart.start) {
    if (!myStart.start && myScreen.time && myScreen.snake1.alive) {
      if (frame % myStart.speed == 0) {
        myScreen.updateScreen();
        textSize(myStart.size/2);
        fill(255, 255, 255);
        text("High Score: " + highScore, myScreen.size.x/2 - 65, myScreen.size.y - myStart.size/2);
      }
      frame += 1;
      myScreen.changeSnakeColor();
    }
  }
  
  if (!myStart.start && !myScreen.time) {
    textSize(50);
    fill(255, 255, 255);
    text("Paused", myScreen.size.x/2 - 70, myScreen.size.y/2 - 40);
    textSize(35);
    text("P to Unpause", myScreen.size.x/2 - 100, myScreen.size.y/2 + 25);
  }
  
  if (!myStart.start && myScreen.multiplayer) {
    if (!myStart.start && !myScreen.snake1.alive && !myScreen.snake2.alive) {
      textSize(50);
      fill(255, 255, 255);
      text("Game Over", myScreen.size.x/2 - 110, myScreen.size.y/2 - 40);
      textSize(35);
      text("R to Retry", myScreen.size.x/2 - 65, myScreen.size.y/2 + 25);
    }
  } else {
    if (!myStart.start && !myScreen.snake1.alive) {
      textSize(50);
      fill(255, 255, 255);
      text("Game Over", myScreen.size.x/2 - 110, myScreen.size.y/2 - 40);
      textSize(35);
      text("R to Retry", myScreen.size.x/2 - 65, myScreen.size.y/2 + 25);
    }
  }

}

public void keyPressed() {
  
  if (!myStart.start) {
    switch (key) {
      
      case 'w':
      if (myScreen.snake1.motion != "down" && myScreen.snake1.motion != "up" && myScreen.snake1.alive) {
        myScreen.snake1.vel = new IntVector(0, -1);
        myScreen.snake1.addTurn("Up");
      }
      break;
      
      case 'a':
      if (myScreen.snake1.motion != "right" && myScreen.snake1.motion != "left" && myScreen.snake1.alive) {
        myScreen.snake1.vel = new IntVector(-1, 0);
        myScreen.snake1.addTurn("Left");
      }
      break;
      
      case 's':
      if (myScreen.snake1.motion != "up" && myScreen.snake1.motion != "down" && myScreen.snake1.alive) {
        myScreen.snake1.vel = new IntVector(0, 1);
        myScreen.snake1.addTurn("Down");
      }
      break;
      
      case 'd':
      if (myScreen.snake1.motion != "left" && myScreen.snake1.motion != "right" && myScreen.snake1.alive) {
        myScreen.snake1.vel = new IntVector(1, 0);
        myScreen.snake1.addTurn("Right");
      }
      break;
      
      case 'p':
      myScreen.pause();
      break;
      
      case 'r':
      if (!myScreen.multiplayer) {
        if ((!myScreen.snake1.alive) && !myStart.start) {
          myScreen = new Screen(1250, 900, myStart.size, myStart.multiplayer);
        }
      } else {
        if ((!myScreen.snake1.alive) && !myStart.start && (!myScreen.snake2.alive)) {
          myScreen = new Screen(1250, 900, myStart.size, myStart.multiplayer);
        }
      }
      break;
    
    }
    
    if (!myScreen.multiplayer) {
      if (keyCode == UP) {
        if (myScreen.snake1.motion != "down" && myScreen.snake1.motion != "up" && myScreen.snake1.alive) {
          myScreen.snake1.vel = new IntVector(0, -1);
          myScreen.snake1.addTurn("Up");
        }
      }
      else if (keyCode == DOWN) {
        if (myScreen.snake1.motion != "up" && myScreen.snake1.motion != "down" && myScreen.snake1.alive) {
          myScreen.snake1.vel = new IntVector(0, 1);
          myScreen.snake1.addTurn("Down");
        }
      }
      else if (keyCode == LEFT) {
        if (myScreen.snake1.motion != "right" && myScreen.snake1.motion != "left" && myScreen.snake1.alive) {
          myScreen.snake1.vel = new IntVector(-1, 0);
          myScreen.snake1.addTurn("Left");
        }
      }
      else if (keyCode == RIGHT) {
        if (myScreen.snake1.motion != "left" && myScreen.snake1.motion != "right" && myScreen.snake1.alive) {
          myScreen.snake1.vel = new IntVector(1, 0);
          myScreen.snake1.addTurn("Right");
        }
      }
    }
    
  }
  
  if (myScreen.multiplayer && !myStart.start) {
    if (keyCode == UP) {
      if (myScreen.snake2.motion != "down" && myScreen.snake2.motion != "up" && myScreen.snake2.alive) {
        myScreen.snake2.vel = new IntVector(0, -1);
        myScreen.snake2.addTurn("Up");
      }
    }
    else if (keyCode == DOWN) {
      if (myScreen.snake2.motion != "up" && myScreen.snake2.motion != "down" && myScreen.snake2.alive) {
        myScreen.snake2.vel = new IntVector(0, 1);
        myScreen.snake2.addTurn("Down");
      }
    }
    else if (keyCode == LEFT) {
      if (myScreen.snake2.motion != "right" && myScreen.snake2.motion != "left" && myScreen.snake2.alive) {
        myScreen.snake2.vel = new IntVector(-1, 0);
        myScreen.snake2.addTurn("Left");
      }
    }
    else if (keyCode == RIGHT) {
      if (myScreen.snake2.motion != "left" && myScreen.snake2.motion != "right" && myScreen.snake2.alive) {
        myScreen.snake2.vel = new IntVector(1, 0);
        myScreen.snake2.addTurn("Right");
      }
    }
  }

}

public void mouseClicked() {
  if (myStart.start) {
    myStart.checkTouch(mouseX, mouseY);
    myScreen = new Screen(1250, 900, myStart.size, myStart.multiplayer);
  }
}
class IntVector {

  int x;
  int y;
  
  public IntVector(int myX, int myY) {
    x = myX;
    y = myY;
  }

}
class MyList {

  ArrayList<IntVector> list;
  
  public MyList(int size) {
  
    list = new ArrayList<IntVector>(size);
    
  }
  
  public boolean listContains(IntVector vec) {
  
    for (int i = 0; i <= list.size() - 1; i++) {
    
      if (list.get(i).x == vec.x && list.get(i).y == vec.y) {
        return true;
      }
      
    }
    return false;
    
  }
  
  public void add(IntVector v) {
    list.add(v);
  }
  
  public void remove(int e) {
    list.remove(e);
  }
  
  public int size() {
    return list.size();
  }
  
  public IntVector get(int index) {
    return list.get(index);
  }


}


class Screen {
  
  IntVector size;
  int[][] screenRep;
  int square;
  Snake snake1;
  Snake snake2;
  IntVector apple = new IntVector(0, 0);
  Random random = new Random();
  boolean time = true;
  int greenColor = 255;
  boolean greenIn = false;
  int blueColor = 100;
  boolean blueIn = false;
  boolean multiplayer;
  
  public Screen() {
  
    size = new IntVector(1250, 900);
    square = 25;
    initScreen();
    snake1 = new Snake();
    multiplayer = false;
  
  }
  
  public Screen(int x, int y, int z, boolean multi) {
    
    size = new IntVector(x, y);
    square = z;
    initScreen();
    snake1 = new Snake(x, y, z);
    multiplayer = multi;
    if (multiplayer) {
      snake1 = new Snake(size.x, size.y, square, size.x/square/4, size.y/square/2);
      snake2 = new Snake(size.x, size.y, square, (size.x/square/4) * 3, size.y/square/2);
    } else {
      snake1 = new Snake(size.x, size.y, square, size.x/square/2, size.y/square/2);
    }

  }
  
  
  public void initScreen() {
  
   screenRep = new int[PApplet.parseInt(size.x/square)][PApplet.parseInt(size.y/square)];
   
   for (int x = 0; x < size.x/square; x++) {
     for (int y = 0; y < size.y/square; y++) {
       
       if (x == 0 || y == 0 || x == size.x/square - 1 || y == size.y/square - 1) {
         screenRep[x][y] = 1;
       }
       else {
         screenRep[x][y] = 0;
       }
       
     }
   }
   
  }
  
  public void drawScreen() {
  
    background(0, 0, 0);
    stroke(255, 255, 255);
    line(square, square, size.x-square, square);
    line(square, square, square, size.y-square);
    line(square, size.y-square, size.x-square, size.y-square);
    line(size.x-square, square, size.x-square, size.y-square);
    fill(255, 255, 255);
    textSize(square/2);
    
    if (!multiplayer) {
      text("Score: " + snake1.score, size.x/2 - 30, square/2);
    } else {
      text("Green Score: " + snake1.score, size.x/4 - 60, square/2);
      text("Blue Score: " + snake2.score, (size.x/4 * 3) - 50, square/2);
    }
    
    noStroke();
    fill(0, greenColor, blueColor);
    
    if (snake1.motion == "up") {
      rect(PApplet.parseInt(snake1.pos.x) * square, PApplet.parseInt(snake1.pos.y) * square, square, square, square/2, square/2, 0, 0);
    }
    else if (snake1.motion == "down") {
      rect(PApplet.parseInt(snake1.pos.x) * square, PApplet.parseInt(snake1.pos.y) * square, square, square, 0, 0, square/2, square/2);
    }
    else if (snake1.motion == "left") {
      rect(PApplet.parseInt(snake1.pos.x) * square, PApplet.parseInt(snake1.pos.y) * square, square, square, square/2, 0, 0, square/2);
    }
    else {
      rect(PApplet.parseInt(snake1.pos.x) * square, PApplet.parseInt(snake1.pos.y) * square, square, square, 0, square/2, square/2, 0);
    }
    
    if (multiplayer) {
      fill(0, blueColor, greenColor);
      if (snake2.motion == "up") {
        rect(PApplet.parseInt(snake2.pos.x) * square, PApplet.parseInt(snake2.pos.y) * square, square, square, square/2, square/2, 0, 0);
      }
      else if (snake2.motion == "down") {
        rect(PApplet.parseInt(snake2.pos.x) * square, PApplet.parseInt(snake2.pos.y) * square, square, square, 0, 0, square/2, square/2);
      }
      else if (snake2.motion == "left") {
        rect(PApplet.parseInt(snake2.pos.x) * square, PApplet.parseInt(snake2.pos.y) * square, square, square, square/2, 0, 0, square/2);
      }
      else {
        rect(PApplet.parseInt(snake2.pos.x) * square, PApplet.parseInt(snake2.pos.y) * square, square, square, 0, square/2, square/2, 0);
      }
      
    }
    if (multiplayer) {
      
      for (int x = 1; x < screenRep.length - 1; x++) {
        for (int y = 1; y < screenRep[x].length - 1; y++) {
          fill(0, greenColor, blueColor);
          if ((snake1.turnUpLeft.listContains(new IntVector(x, y))) || (snake1.turnRightDown.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, 0, square/2, 0, 0);
          } else if ((snake1.turnUpRight.listContains(new IntVector(x, y))) || (snake1.turnLeftDown.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, square/2, 0, 0, 0);
          } else if ((snake1.turnDownLeft.listContains(new IntVector(x, y))) || (snake1.turnRightUp.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, 0, 0, square/2, 0);
          } else if ((snake1.turnDownRight.listContains(new IntVector(x, y))) || (snake1.turnLeftUp.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, 0, 0, 0, square/2);
          } else if ((snake2.turnUpLeft.listContains(new IntVector(x, y))) || (snake2.turnRightDown.listContains(new IntVector(x, y)))) {
            fill(0, blueColor, greenColor);
            rect(x*square, y*square, square, square, 0, square/2, 0, 0);
          } else if ((snake2.turnUpRight.listContains(new IntVector(x, y))) || (snake2.turnLeftDown.listContains(new IntVector(x, y)))) {
            fill(0, blueColor, greenColor);
            rect(x*square, y*square, square, square, square/2, 0, 0, 0);
          } else if ((snake2.turnDownLeft.listContains(new IntVector(x, y))) || (snake2.turnRightUp.listContains(new IntVector(x, y)))) {
            fill(0, blueColor, greenColor);
            rect(x*square, y*square, square, square, 0, 0, square/2, 0);
          } else if ((snake2.turnDownRight.listContains(new IntVector(x, y))) || (snake2.turnLeftUp.listContains(new IntVector(x, y)))) {
            fill(0, blueColor, greenColor);
            rect(x*square, y*square, square, square, 0, 0, 0, square/2);
          } else {
            if (screenRep[x][y] == 2 && !(x == PApplet.parseInt(snake1.pos.x) && y == PApplet.parseInt(snake1.pos.y))) {
              fill(0, greenColor, blueColor);
              rect(x*square, y*square, square, square);
            } else if (screenRep[x][y] == 4 && !(x == PApplet.parseInt(snake2.pos.x) && y == PApplet.parseInt(snake2.pos.y))) {
              fill(0, blueColor, greenColor);
              rect(x*square, y*square, square, square);
            } else if (screenRep[x][y] == 3) {
              fill(255, 0, 0);
              ellipse(x*square + square/2, y*square + square/2, square - square/5, square - square/5);
            }
          }
        }
      }
      
    } else {
      
      for (int x = 1; x < screenRep.length - 1; x++) {
        for (int y = 1; y < screenRep[x].length - 1; y++) {
          fill(0, greenColor, blueColor);
          if ((snake1.turnUpLeft.listContains(new IntVector(x, y))) || (snake1.turnRightDown.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, 0, square/2, 0, 0);
          } else if ((snake1.turnUpRight.listContains(new IntVector(x, y))) || (snake1.turnLeftDown.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, square/2, 0, 0, 0);
          } else if ((snake1.turnDownLeft.listContains(new IntVector(x, y))) || (snake1.turnRightUp.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, 0, 0, square/2, 0);
          } else if ((snake1.turnDownRight.listContains(new IntVector(x, y))) || (snake1.turnLeftUp.listContains(new IntVector(x, y)))) {
            rect(x*square, y*square, square, square, 0, 0, 0, square/2);
          } else {
            if (screenRep[x][y] == 2 && !(x == PApplet.parseInt(snake1.pos.x) && y == PApplet.parseInt(snake1.pos.y))) {
              fill(0, greenColor, blueColor);
              rect(x*square, y*square, square, square);
            }
            else if (screenRep[x][y] == 4 && !(x == PApplet.parseInt(snake2.pos.x) && y == PApplet.parseInt(snake2.pos.y))) {
              fill(0, blueColor, greenColor);
              rect(x*square, y*square, square, square);
            }
            else if (screenRep[x][y] == 3) {
              fill(255, 0, 0);
              ellipse(x*square + square/2, y*square + square/2, square - square/5, square - square/5);
            }
          }
        }
      }
      
    }
    
  }
  
  public void newApple() {
    while (screenRep[PApplet.parseInt(apple.x)][PApplet.parseInt(apple.y)] == 4 || screenRep[PApplet.parseInt(apple.x)][PApplet.parseInt(apple.y)] == 2 || apple.x == 0 || apple.y == 0) {
      apple.x = random.nextInt(PApplet.parseInt(size.x/square)-1);
      apple.y = random.nextInt(PApplet.parseInt(size.y/square)-1);
    }
  }
  
  
  public void updateScreen() {
  
    if (!multiplayer) {
      if (snake1.alive) {
        newApple();
        screenRep[PApplet.parseInt(apple.x)][PApplet.parseInt(apple.y)] = 3;
        snake1.updateSnake(screenRep);
        screenRep[PApplet.parseInt(snake1.pos.x)][PApplet.parseInt(snake1.pos.y)] = 2;
        if (snake1.removed != null) {
          screenRep[PApplet.parseInt(snake1.removed.x)][PApplet.parseInt(snake1.removed.y)] = 0;
        }
      }
    } else {
      if (snake2.alive || snake1.alive) {
        newApple();
        screenRep[PApplet.parseInt(apple.x)][PApplet.parseInt(apple.y)] = 3;
        snake1.updateSnake(screenRep);
        snake2.updateSnake(screenRep);
        screenRep[PApplet.parseInt(snake1.pos.x)][PApplet.parseInt(snake1.pos.y)] = 2;
        screenRep[PApplet.parseInt(snake2.pos.x)][PApplet.parseInt(snake2.pos.y)] = 4;
        if (snake1.removed != null) {
          screenRep[PApplet.parseInt(snake1.removed.x)][PApplet.parseInt(snake1.removed.y)] = 0;
        }
        if (snake2.removed != null) {
          screenRep[PApplet.parseInt(snake2.removed.x)][PApplet.parseInt(snake2.removed.y)] = 0;
        }
      }
    }
    
    drawScreen();
    
  }
  
  public void pause() {
    if (time == true) {
      time = false;
    }
    else {
      time = true;
    }
  }
  
  public void changeSnakeColor() {
    
    if (greenColor >= 255) {
      greenIn = false;
    } else if (greenColor <= 150) {
      greenIn = true;
    }
    
    if (greenIn) {
      greenColor += 1;
    } else {
      greenColor -= 1;
    }
    
    
    
    if (blueColor >= 150) {
      blueIn = false;
    } else if (blueColor <= 30) {
      blueIn = true;
    }
    
    if (blueIn) {
      blueColor += 1;
    } else {
      blueColor -= 1;
    }
    
  }
  
}
class Snake {

  IntVector vel = new IntVector(0, -1);
  int len = 3;
  int score = 0;
  IntVector pos;
  ArrayList<IntVector> pieces = new ArrayList<IntVector>(1000);
  int pieceSize;
  IntVector screenSize;
  boolean alive = true;
  IntVector removed;
  IntVector added;
  String motion;
  MyList turnUpLeft = new MyList(1000);
  MyList turnUpRight = new MyList(1000);
  MyList turnDownLeft = new MyList(1000);
  MyList turnDownRight = new MyList(1000);
  MyList turnRightUp = new MyList(1000);
  MyList turnLeftUp = new MyList(1000);
  MyList turnRightDown = new MyList(1000);
  MyList turnLeftDown = new MyList(1000);

  public Snake() {
  
    pieceSize = 25;
    screenSize = new IntVector(1250/pieceSize, 900/pieceSize);
    pos = new IntVector(screenSize.x/2, screenSize.y/2);
    motion = "up";
  
  }
  
  public Snake(int x, int y, int z) {
    
    pieceSize = z;
    screenSize = new IntVector(x/pieceSize, y/pieceSize);
    pos = new IntVector(screenSize.x/2, screenSize.y/2);
    motion = "up";
    
  }
  
  public Snake(int x, int y, int z, int startingPosx, int startingPosy) {
    
    pieceSize = z;
    pos = new IntVector(startingPosx, startingPosy);
    screenSize = new IntVector(x/pieceSize, y/pieceSize);
    motion = "up";
    
  }
  
  
  public void updateSnake(int[][] screen) {
  
    if (vel.x == 1) {
      motion = "right";
    }
    else if (vel.x == -1) {
      motion = "left";
    }
    else if (vel.y == 1) {
      motion = "down";
    }
    else if (vel.y == -1) {
      motion = "up";
    }
    
    if (hitBad(screen, PApplet.parseInt(pos.x) + PApplet.parseInt(vel.x), PApplet.parseInt(pos.y) + PApplet.parseInt(vel.y))) {
      alive = false;
    }
    if (eat(screen)) {
      len += 3;
    }
    
    pos.x += vel.x;
    pos.y += vel.y;
    
    if (alive) {
      pieces.add(new IntVector(pos.x, pos.y));
      if (eat(screen)) {
        len += 3;
        score +=1;
      }
      if (pieces.size() > len) {
        removed = pieces.get(0);
        manageCorners();
        pieces.remove(0);
      }
    }
    
  }
  
  public boolean hitBad(int[][] screen, int x, int y) {
    
    if (screen[PApplet.parseInt(x)][PApplet.parseInt(y)] == 1 || screen[PApplet.parseInt(x)][PApplet.parseInt(y)] == 2 || screen[PApplet.parseInt(x)][PApplet.parseInt(y)] == 4) {
      vel = new IntVector(0, 0);
      return true;
    }
    else {
      return false;
    }
    
  }
  
  public void addTurn(String turnDir) {
    String theTurn = motion + turnDir;
    
    switch (theTurn) {
      
      case "upLeft":
      turnUpLeft.add(new IntVector(pos.x, pos.y));
      break;
      
      case "upRight":
      turnUpRight.add(new IntVector(pos.x, pos.y));
      break;
      
      case "downLeft":
      turnDownLeft.add(new IntVector(pos.x, pos.y));
      break;
      
      case "downRight":
      turnDownRight.add(new IntVector(pos.x, pos.y));
      break;
      
      case "rightDown":
      turnRightDown.add(new IntVector(pos.x, pos.y));
      break;
      
      case "leftDown":
      turnLeftDown.add(new IntVector(pos.x, pos.y));
      break;
      
      case "rightUp":
      turnRightUp.add(new IntVector(pos.x, pos.y));
      break;
      
      case "leftUp":
      turnLeftUp.add(new IntVector(pos.x, pos.y));
      break;
    }
  }
  
  public void manageCorners() {
    if (turnUpLeft.size() > 0 && pieces.get(0).x == turnUpLeft.get(0).x && pieces.get(0).y == turnUpLeft.get(0).y) {
      turnUpLeft.remove(0);
    } else if (turnDownLeft.size() > 0 && pieces.get(0).x == turnDownLeft.get(0).x && pieces.get(0).y == turnDownLeft.get(0).y) {
      turnDownLeft.remove(0);
    } else if (turnDownRight.size() > 0 && pieces.get(0).x == turnDownRight.get(0).x && pieces.get(0).y == turnDownRight.get(0).y) {
      turnDownRight.remove(0);
    } else if (turnUpRight.size() > 0 && pieces.get(0).x == turnUpRight.get(0).x && pieces.get(0).y == turnUpRight.get(0).y) {
      turnUpRight.remove(0);
    } else if (turnLeftUp.size() > 0 && pieces.get(0).x == turnLeftUp.get(0).x && pieces.get(0).y == turnLeftUp.get(0).y) {
      turnLeftUp.remove(0);
    } else if (turnLeftDown.size() > 0 && pieces.get(0).x == turnLeftDown.get(0).x && pieces.get(0).y == turnLeftDown.get(0).y) {
      turnLeftDown.remove(0);
    } else if (turnRightUp.size() > 0 && pieces.get(0).x == turnRightUp.get(0).x && pieces.get(0).y == turnRightUp.get(0).y) {
      turnRightUp.remove(0);
    } else if (turnRightDown.size() > 0 && pieces.get(0).x == turnRightDown.get(0).x && pieces.get(0).y == turnRightDown.get(0).y) {
      turnRightDown.remove(0);
    }
  }
  
  public boolean eat(int[][] screen) {
  
    if (screen[PApplet.parseInt(pos.x)][PApplet.parseInt(pos.y)] == 3) {
      return true;
    }
    else {
      return false;
    }
  
  }

}
class Start {

  int size;
  boolean start;
  IntVector screenSize;
  IntVector pos25;
  IntVector pos50;
  IntVector speedFast;
  IntVector speedSlow;
  IntVector singlePlayer;
  IntVector multiPlayerB;
  int speed;
  boolean speedPick = false;
  boolean sizePick = false;
  boolean multiPick = false;
  Vector3 lineColor = new Vector3(255, 0, 127);
  boolean rIn = false;
  boolean gIn = true;
  boolean bIn = true;
  Random random = new Random();
  boolean multiplayer;
  IntVector colorSquare;
  IntVector colorSize;
  
  public Start() {
    size = 25;
    start = true;
    screenSize = new IntVector(1250, 900);
    pos25 = new IntVector(screenSize.x/2 - 300, screenSize.y/2 - 50);
    pos50 = new IntVector(screenSize.x/2, screenSize.y/2 - 50);
    speedFast = new IntVector(screenSize.x/2 - 300, screenSize.y/2 + 100);
    speedSlow = new IntVector(screenSize.x/2, screenSize.y/2 + 100);
    singlePlayer = new IntVector(screenSize.x/2, screenSize.y/2 + 250);
    multiPlayerB = new IntVector(screenSize.x/2 - 300, screenSize.y/2 + 250);
    colorSquare = new IntVector(screenSize.x/3, screenSize.y/(3/2));
    colorSize = new IntVector(255, 100);
  }
  
  public Start(int square, IntVector sizeS) {
    size = square;
    start = true;
    screenSize = new IntVector(sizeS.x, sizeS.y);
    pos25 = new IntVector(screenSize.x/2 - 300, screenSize.y/2 - 50);
    pos50 = new IntVector(screenSize.x/2, screenSize.y/2 - 50);
    speedFast = new IntVector(screenSize.x/2 - 300, screenSize.y/2 + 100);
    speedSlow = new IntVector(screenSize.x/2, screenSize.y/2 + 100);
    singlePlayer = new IntVector(screenSize.x/2, screenSize.y/2 + 250);
    multiPlayerB = new IntVector(screenSize.x/2 - 300, screenSize.y/2 + 250);
    colorSquare = new IntVector(screenSize.x/3, screenSize.y/(3/2));
    colorSize = new IntVector(255, 100);
  }
  
  public void drawStart() {
    background(0, 0, 0);
    changeLineColor();
    fill(lineColor.x, lineColor.y, lineColor.z);
    noStroke();
    rect(0, 0, 15, screenSize.y);
    rect(0, 0, screenSize.x, 15);
    rect(screenSize.x - 15, 15, screenSize.x - 15, screenSize.y - 15);
    rect(0, screenSize.y - 15, screenSize.x, 15);
    textSize(75);
    fill(0, 255, 0);
    text("Snake", screenSize.x/2 - 95, 175);
    textSize(25);
    stroke(0, 0, 0);
    fill(255);
    text("Choose Settings", screenSize.x/2 - 90, (screenSize.y/2) - 175);
    text("Controls:\nW-A-S-D or Arrows to Move\nP to Pause / Unpause", 100, 100);
    text("Recommended:\nSmall / Fast / Multiplayer\nBig / Slow / Single Player", screenSize.x - 400, 100);
    fill(255, 0, 255);
    rect(pos25.x, pos25.y, 300, 100);
    fill(0);
    text("Small", pos25.x + 120, screenSize.y/2 + 10);
    fill(0, 255, 255);
    rect(pos50.x, pos50.y, 300, 100);
    fill(0);
    text("Big", pos50.x + 130, screenSize.y/2 + 10);
    
    fill(255, 0, 255);
    rect(speedFast.x, speedFast.y, 300, 100);
    fill(0);
    text("Fast", speedFast.x + 120, screenSize.y/2 + 160);
    fill(0, 255, 255);
    rect(speedSlow.x, speedSlow.y, 300, 100);
    fill(0);
    text("Slow", speedSlow.x + 130, screenSize.y/2 + 160);
    
    fill(255, 0, 255);
    rect(multiPlayerB.x, multiPlayerB.y, 300, 100);
    fill(0);
    text("Multiplayer", multiPlayerB.x + 90, screenSize.y/2 + 310);
    fill(0, 255, 255);
    rect(singlePlayer.x, singlePlayer.y, 300, 100);
    fill(0);
    text("Single Player", singlePlayer.x + 80, screenSize.y/2 + 310);
    
  }
  
  public void checkTouch(int x, int y) {
    if (x >= pos25.x && x <= pos25.x + 300 && y >= pos25.y && y <= pos25.y + 100) {
      size = 25;
      sizePick = true;
    } else if (x >= pos50.x && x <= pos50.x + 300 && y >= pos50.y && y <= pos50.y + 100) {
      size = 50;
      sizePick = true;
    } else if (x >= speedFast.x && x <= speedFast.x + 300 && y >= speedFast.y && y <= speedFast.y + 100) {
      speed = 7;
      speedPick = true;
    } else if (x >= speedSlow.x && x <= speedSlow.x + 300 && y >= speedSlow.y && y <= speedSlow.y + 100) {
      speed = 10;
      speedPick = true;
    } 
    
    else if (x >= multiPlayerB.x && x <= multiPlayerB.x + 300 && y >= multiPlayerB.y && y <= multiPlayerB.y + 100) {
      multiplayer = true;
      multiPick = true;
    } else if (x >= singlePlayer.x && x <= singlePlayer.x + 300 && y >= singlePlayer.y && y <= singlePlayer.y + 100) {
      multiplayer = false;
      multiPick = true;
    }
    
    if (speedPick && sizePick && multiPick) {
      start = false;
    }
    
  }
  
  public void changeLineColor() {
    if (lineColor.x >= 255) {
      rIn = false;
    } else if (lineColor.x < 0) {
      rIn = true;
    }
    if (lineColor.y >= 255) {
      gIn = false;
    } else if (lineColor.y < 0) {
      gIn = true;
    }
    if (lineColor.z >= 255) {
      bIn = false;
    } else if (lineColor.z < 0) {
      bIn = true;
    }
    
    if (rIn) {
      lineColor.x += random.nextInt(4);
    } else {
      lineColor.x -= random.nextInt(4);
    }
    if (gIn) {
      lineColor.y += random.nextInt(4);
    } else {
      lineColor.y -= random.nextInt(4);
    }
    if (bIn) {
      lineColor.z += random.nextInt(4);
    } else {
      lineColor.z -= random.nextInt(4);
    }
    
    
  }


}
class Vector3 {

  int x;
  int y;
  int z;
  
  
  public Vector3(int myX, int myY, int myZ) {
  
    x = myX;
    y = myY;
    z = myZ;
    
  }
  
}
  public void settings() {  size(1250, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Snake_Game" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
